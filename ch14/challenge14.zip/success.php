<!DOCTYPE HTML>
<html>
<head>
    <title>Challenge 14</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: lightpink">
<div style="text-align: center;">
    <table class="main-table">
        <tbody>
        <tr>
            <td>
                <p><img src="java_logo.png" width="100" alt="logo"></p>
            </td>
        <tr>
            <td class="main-content">
                <div style="text-align: center;">
                    <h1 style="margin-top: 10px">
                        <b>SUCCESS</b>
                    </h1>
                </div>
            </TD>
        </TR>
        </TBODY>
    </TABLE>
</div>
</BODY>
</HTML>
