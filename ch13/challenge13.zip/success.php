<!DOCTYPE HTML>
<html>
<head>
    <title>Challenge 13</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: burlywood">
<div style="text-align: center;">
    <table class="main-table">
        <tbody>
        <tr>
            <td>
                <p><img src="js_logo.png" width="100" alt="logo"></p>
            </td>
        <tr>
            <td class="main-content">
                <div style="text-align: center;">
                    <h1 style="margin-top: 10px">
                        <b>SUCCESS</b>
                    </h1>
                </div>
            </td>
        </tr>
        </tbody>
    </table>
</div>
</body>
</html>
