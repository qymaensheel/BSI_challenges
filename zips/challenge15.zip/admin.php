<!DOCTYPE HTML>
<html>
<head>
    <title>Challenge 15</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: aquamarine">
<div style="text-align: center;">
    <table class="main-table">
        <TBODY>
        <tr>
            <td width="86%" height="104">
                <p><img src="url_interpretation_logo.png" width="100"></p></td>
        </tr>
        <tr>
            <td>
                <h2>Welcome to admin portal. Please log in</h2>
            </td>
        </tr>
        <TR>
            <TD class="main-content">
                <form action="admin_login.php" method="post">
                    <p align="center">Enter your credentials:
                        <input type="text" name="login" size="20">
                        <input type="text" name="passwd" size="20">
                        <input type="submit" value="Enter" name="submit">
                    </p>
                </form>
            </TD>
        </TR>
        </TBODY>
    </TABLE>
</div>
</BODY>
</HTML>
