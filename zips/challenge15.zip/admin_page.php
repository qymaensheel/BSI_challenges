<!DOCTYPE HTML>
<html>
<head>
    <title>Challenge 15</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: aquamarine">
<div style="text-align: center;">
    <table class="main-table">
        <tbody>
        <tr>
        <td style="text-align: left">
            <button><a href="index.php">
                logout</a>
            </button>
        </td></tr>
        <tr>
            <td>
                <p><img src="url_interpretation_logo.png" width="100"></p>
                <h2>User <b>admin</b> logged in. </h2>
            </td>
        </tr>
        <tr><td class="main-content">

            <h4>List of all users:</h4>
        <table border="1" align="center" style="margin-top: 30px">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
            </tr>
            <tr>
                <td>ajglfho875</td>
                <td>ben_dover</td>
                <td>qwerty</td>
            </tr>
            <tr>
                <td>ksop58g7j3</td>
                <td>jumbo1</td>
                <td>12345678</td>
            </tr>
            <tr>
                <td>ask394ofpl</td>
                <td>big_poppa</td>
                <td>zaq12wsx</td>
            </tr>
        </table>
        </td></tr>
        </tbody>
    </TABLE>
</div>
</BODY>
</HTML>
