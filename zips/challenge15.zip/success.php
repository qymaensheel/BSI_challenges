<!DOCTYPE HTML>
<html>
<head>
    <title>Challenge 15</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: aquamarine">
<div style="text-align: center;">
    <table class="main-table">
        <TBODY>
        <tr>
            <td>
                <p><img src="url_interpretation_logo.png" width="100"></p>
        <TR>
            <TD class="main-content">
                <div style="text-align: center;">
                    <h1 style="margin-top: 10px">
                        <b>SUCCESS</b>
                    </h1>
                </div>
            </TD>
        </TR>
        </TBODY>
    </TABLE>
</div>
</BODY>
</HTML>
