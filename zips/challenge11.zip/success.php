<!DOCTYPE HTML>
<html>
<head>
<?php
include_once dirname(__FILE__).'/../../init.php';
require_once(HACKADEMIC_PATH."pages/challenge_monitor.php");
?>
    
    <title>Challenge 11</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: darkcyan">
<div style="text-align: center;">
    <table class="main-table">
        <tbody>
        <tr>
            <td>
                <p><img src="logo.png" width="100" alt="logo"></p>
            </td>
        <tr>
            <td class="main-content">
                <div style="text-align: center;">
                    <h1 style="margin-top: 10px">
                        <b>SUCCESS</b>
                    </h1>
                </div>
            </td>
        </tr>
        </tbody>
    </TABLE>
</div>
</BODY>
</HTML>
